using namespace std;

struct ChunkHeader
{
	char tag[4];
	uint32 size;
};

struct Extent
{
	float boundsRadius;
	float minimum[3];
	float maximum[3];
};

struct Node
{
	uint32 inclusiveSize;
	char name[80];
	uint32 objectId;
	uint32 parentId;
	uint32 flags; // 0x0: helper
			    // 0x1: dont inherit translation
			    // 0x2: dont inherit rotation
			    // 0x4: dont inherit scaling
			    // 0x8: billboarded
			    // 0x10: billboarded lock x
			    // 0x20: billboarded lock y
			    // 0x40: billboarded lock z
			    // 0x80: camera anchored
			    // 0x100: bone
			    // 0x200: light
			    // 0x400 event object
			    // 0x800: attachment
			    // 0x1000 particle emitter
			    // 0x2000: collision shape
			    // 0x4000: ribbon emitter
			    // 0x8000: if particle emitter: emitter uses mdl, if particle emitter 2: unshaded
			    // 0x10000: if particle emitter: emitter uses tga, if particle emitter 2: sort primitives far z
			    // 0x20000: line emitter
			    // 0x40000: unfogged
			    // 0x80000: model space
			    // 0x100000: xy quad
  //(KGTR)
  //(KGRT)
  //(KGSC)
};

struct Sequence
{
	char name[80];
	uint32 interval[2];
	float moveSpeed;
	uint32 flags; // 0: looping
			      // 1: non looping
	float rarity;
	uint32 syncPoint;
	Extent extent;
};

struct Texture
{
	uint32 replaceableId;
	char fileName[260];
	uint32 flags;
};

struct SoundTrack
{
	char fileName[260];
	float volume;
	float pitch;
	uint32 flags;
};

struct Material
{
	uint32 inclusiveSize;
	uint32 priorityPlane;
	uint32 flags;

	char shader[80];

	char lays[4];
	uint32 layersCount;
	//Layer layers[layersCount];
};

struct Layer
{
	uint32 inclusiveSize;
	uint32 filterMode; // 0: none
					// 1: transparent
					// 2: blend
					// 3: additive
					// 4: add alpha
					// 5: modulate
					// 6: modulate 2x
	uint32 shadingFlags; // 0x1: unshaded
					  // 0x2: sphere environment map
					  // 0x4: ?
					  // 0x8: ?
					  // 0x10: two sided
					  // 0x20: unfogged
					  // 0x30: no depth test
					  // 0x40: no depth set
	uint32 textureId;
	uint32 textureAnimationId;
	uint32 coordId;
	float alpha;
	float emissiveGain;
	float fresnelColor[3];
	float fresnelOpacity;
	float fresnelTeamColor;

  /*(KMTF)
    (KMTA)
    (KMTE)
	(KFC3)
	(KFCA)
	(KFTC)*/
};

struct TextureAnimation
{
	uint32 inclusiveSize;
	    //(KTAT)
		//(KTAR)
		//(KTAS)
};

struct Geoset
{
	uint32 inclusiveSize;
	char VRTX[4];
	uint32 vertexCount;
	//float vertexPositions[vertexCount * 3];
	char NRMS[4];
	uint32 normalCount;
	//float vertexNormals[normalCount * 3];
	char PTYP[4];
	uint32 faceTypeGroupsCount;
	//uint32 faceTypeGroups[faceTypeGroupsCount]; // 0: points
												   // 1: lines
												   // 2: line loop
												   // 3: line strip
												   // 4: triangles
												   // 5: triangle strip
												   // 6: triangle fan
												   // 7: quads
												   // 8: quad strip
												   // 9: polygons
	char PCNT[4];
	uint32 faceGroupsCount;
	//uint32 faceGroups[faceGroupsCount];
	char PVTX[4];
	uint32 facesCount;
	//uint16 faces[facesCount];
	char GNDX[4];
	uint32 vertexGroupsCount;
	//uint8 vertexGroups[vertexGroupsCount];
	char MTGC[4];
	uint32 matrixGroupsCount;
	//uint32 matrixGroups[matrixGroupsCount];
	char MATS[4];
	uint32 matrixIndicesCount;
	//uint32 matrixIndices[matrixIndicesCount];
	uint32 materialId;
	uint32 selectionGroup;
	uint32 selectionFlags;

	uint32 lod;
	char lodName[80];

	Extent extent;
	uint32 extentsCount;
	//Extent sequenceExtents[extentsCount];

	//(Tangents)
	//(Skin)

	char UVAS[4];
	uint32 textureCoordinateSetsCount;
	//TextureCoordinateSet textureCoordinateSets[textureCoordinateSetsCount];
};

struct Tangents
{
	char TANG[4];
	uint32 count;
	//float tangents[count * 4];
};

struct Skin
{
	char SKIN[4];
	uint32 count;
	//uint8 skin[count];
};

struct Boneweight
{
	uint8 boneIndex0;
	uint8 boneIndex1;
	uint8 boneIndex2;
	uint8 boneIndex3;
	uint8 weight0;
	uint8 weight1;
	uint8 weight2;
	uint8 weight3;
};

struct TextureCoordinateSet
{
	char UVBS[4];
	uint32 count;
	//float texutreCoordinates[count * 2];
};

struct GeosetAnimation
{
	uint32 inclusiveSize;
	float alpha;
	uint32 flags;
	float color[3];
	uint32 geosetId;
  //(KGAO)
  //(KGAC)
};

struct Bone
{
	Node node;
	uint32 geosetId;
	uint32 geosetAnimationId;
};

struct Light
{
	uint32 inclusiveSize;
	Node node;
	uint32 type; // 0: omni light
			  // 1: directional light
			  // 2: ambient light
	float attenuationStart;
	float attenuationEnd;
	float color[3];
	float intensity;
	float ambientColor[3];
	float ambientIntensity;
  /*(KLAS)
  (KLAE)
  (KLAC)
  (KLAI)
  (KLBI)
  (KLBC)
  (KLAV)*/
};

struct Helper
{
	Node node;
};

struct Attachment
{
	uint32 inclusiveSize;
	Node node;
	char path[260];
	uint32 attachmentId;
  //(KATV)
};

struct ParticleEmitter
{
	uint32 inclusiveSize;
	Node node;
	float emissionRate;
	float gravity;
	float longitude;
	float latitude;
	char spawnModelFileName[260];
	float lifespan;
	float initialiVelocity;
  /*(KPEE)
  (KPEG)
  (KPLN)
  (KPLT)
  (KPEL)
  (KPES)
  (KPEV)*/
};

struct ParticleEmitter2
{
	uint32 inclusiveSize;
	Node node;
	float speed;
	float variation;
	float latitude;
	float gravity;
	float lifespan;
	float emissionRate;
	float length;
	float width;
	uint32 filterMode; // 0: blend
					// 1: additive
					// 2: modulate
					// 3: modulate 2x
					// 4: alpha key
	uint32 rows;
	uint32 columns;
	uint32 headOrTail;// 0: head
					// 1: tail
					// 2: both
	float tailLength;
	float time;
	float segmentColor[3][3];
	uint8 segmentAlpha[3];
	float segmentScaling[3];
	uint32 headInterval[3];
	uint32 headDecayInterval[3];
	uint32 tailInterval[3];
	uint32 tailDecayInterval[3];
	uint32 textureId;
	uint32 squirt;
	uint32 priorityPlane;
	uint32 replaceableId;
  /*(KP2S)
  (KP2R)
  (KP2L)
  (KP2G)
  (KP2E)
  (KP2N)
  (KP2W)
  (KP2V)*/
};

struct RibbonEmitter
{
	uint32 inclusiveSize;
	Node node;
	float heightAbove;
	float heightBelow;
	float alpha;
	float color[3];
	float lifespan;
	uint32 textureSlot;
	uint32 emissionRate;
	uint32 rows;
	uint32 columns;
	uint32 materialId;
	float gravity;
  /*(KRHA)
  (KRHB)
  (KRAL)
  (KRCO)
  (KRTX)
  (KRVS)*/
};

struct EventObject
{
	Node node;
	char KEVT[4];
	uint32 tracksCount;
	uint32 globalSequenceId;
	//uint32 tracks[tracksCount];
};

struct Camera
{
	uint32 inclusiveSize;
	char name[80];
	float position[3];
	float filedOfView;
	float farClippingPlane;
	float nearClippingPlane;
	float targetPosition[3];
  /*(KCTR)
  (KTTR)
  (KCRL)*/
};

struct CollisionShape
{
	Node node;
	uint32 type; // 0: cube
			  // 1: plane
			  // 2: sphere
			  // 3: cylinder
  //float[? ][3] vertices // type 0: 2
					   // type 1: 2
					   // type 2: 1
					   // type 3: 2
  /*if (type == 2 || type == 3) {
	float radius
  }*/
};

struct CornEmitter
{
	uint32 inclusiveSize;
	Node node;
	float lifeSpan;
	float emissionRate;
	float speed;
	float color[4];
	uint32 replaceableId;
	char path[260];
	char flags[260];
		/*(KPPA)
		(KPPC)
		(KPPE)
		(KPPL)
		(KPPS)
		(KPPV)*/
};

struct TracksChunk
{
	char tag[4];
	uint32 tracksCount;
	uint32 interpolationType; // 0: none
						      // 1: linear
							  // 2: hermite
						      // 3: bezier
	uint32 globalSequenceId;
  //Track[tracksCount] tracks
};

struct KGTR
{
	int32 frame;
	Vec3F translation;
};

struct KGRT
{
	int32 frame;
	Vec4F rotation;
};

struct KGSC
{
	int32 frame;
	Vec3F scale;
};

bool compareByValue(Node a, Node b)
{
	return a.objectId < b.objectId;
}

class MDXdata
{
public:
	// VERS
	uint32 version;

	// MODL
	char name[80];
	char animationFileName[260];
	Extent extent;
	uint32 blendTime;

	// SEQS
	std::vector<Sequence> sequences;

	// GLBS
	std::vector<uint32> globalSequences;

	// TEXS
	std::vector<Texture> textures;

	// PIVT
	std::vector<Vec3F> PivotPoints;

	// MTLS, int is materialid
	std::vector<Material> materials;
	std::map<int, std::vector<Layer>> layers;

	std::map<int, std::vector<Layer>> geoslayers;

	// GEOS, int is geosetid
	std::map<int, std::vector<Vec3F>> vertexPositions;
	std::map<int, std::vector<Vec3F>> vertexNormals;
	std::map<int, std::vector<triangle>> PrimitiveVertices;
	std::map<int, uint32> lods;
	std::map<int, std::vector<uint32>> materialIds;
	std::map<int, std::vector<Vec2F>> textureCoordinates;
	std::map<int, std::vector<Boneweight>> boneweights;

	// GEOA
	std::vector<GeosetAnimation> geosetanimations;

	// BONE, int is boneid
	std::vector<Node> bones;
	std::map<int, std::vector<KGTR>> KGTRs;
	std::map<int, std::vector<KGRT>> KGRTs;
	std::map<int, std::vector<KGSC>> KGSCs;

	// m2 anim id equivalent of mdx anim names
	std::map<string, uint32> M2AnimIDs;

	void FillDataFromMDX(string filename)
	{
		ifstream mdx(filename, ios::binary);
		mdx.seekg(0, ios::end);
		const long filesize(mdx.tellg());
		mdx.seekg(4, ios::beg);

		// iterate through chunks
		while (mdx.tellg() != filesize)
		{
			ChunkHeader chunkheader;
			mdx.read(reinterpret_cast<char*>(&chunkheader), sizeof(ChunkHeader));
			long savepos (mdx.tellg()); // pos after chunk header

			if (!strncmp(chunkheader.tag, "MODL", 4))
				mdx.read(reinterpret_cast<char*>(&name), sizeof(char) * 80);
			
			if (!strncmp(chunkheader.tag, "SEQS", 4))
			{
				while (mdx.tellg() != (savepos + chunkheader.size))
				{
					Sequence seq;
					mdx.read(reinterpret_cast<char*>(&seq), sizeof(Sequence));
					sequences.push_back(seq);

					string animname(seq.name, end(seq.name)); // need this because seq.name is not null terminated
					cout << "Enter AnimID for " << animname << endl;
					uint32 animID;
					cin >> animID;
					M2AnimIDs[animname] = animID;
				}
			}

			if (!strncmp(chunkheader.tag, "TEXS", 4))
			{
				while (mdx.tellg() != (savepos + chunkheader.size))
				{
					Texture tex;
					mdx.read(reinterpret_cast<char*>(&tex), sizeof(Texture));
					textures.push_back(tex);
				}
			}

			if (!strncmp(chunkheader.tag, "PIVT", 4))
			{
				while (mdx.tellg() != (savepos + chunkheader.size))
				{
					Vec3F pivot;
					mdx.read(reinterpret_cast<char*>(&pivot), sizeof(Vec3F));
					PivotPoints.push_back(pivot);
				}
			}

			if (!strncmp(chunkheader.tag, "MTLS", 4))
			{
				int matcount = 0;
				while (mdx.tellg() != (savepos + chunkheader.size))
				{
					Material mat;
					mdx.read(reinterpret_cast<char*>(&mat), sizeof(Material));

					for (int i = 0; i < mat.layersCount; ++i)
					{
						long savepos2 = mdx.tellg();
						Layer layer;
						mdx.read(reinterpret_cast<char*>(&layer), sizeof(Layer));
						layers[matcount].push_back(layer);
						if (layer.inclusiveSize > sizeof(Layer))
							mdx.seekg(savepos2 + layer.inclusiveSize);
					}
					materials.push_back(mat);
					matcount++;
				}
			}

			if (!strncmp(chunkheader.tag, "GEOS", 4))
			{
				int geosetcount = 0;
				int vertexcount = 0;
				while (mdx.tellg() != (savepos + chunkheader.size))
				{
					uint32 inclusiveSize;
					mdx.read(reinterpret_cast<char*>(&inclusiveSize), sizeof(uint32));
					long savepos2 = mdx.tellg();					

					while (mdx.tellg() != (savepos2 + (inclusiveSize - sizeof(uint32))))
					{
						ChunkHeader chunkheader2; // size is count here
						mdx.read(reinterpret_cast<char*>(&chunkheader2), sizeof(ChunkHeader));

						if (!strncmp(chunkheader2.tag, "VRTX", 4))
						{
							for (int i = 0; i < chunkheader2.size; ++i)
							{
								Vec3F vertexpos;
								mdx.read(reinterpret_cast<char*>(&vertexpos), sizeof(Vec3F));
								vertexPositions[geosetcount].push_back(vertexpos);
							}
						}

						if (!strncmp(chunkheader2.tag, "NRMS", 4))
						{
							for (int i = 0; i < chunkheader2.size; ++i)
							{
								Vec3F norm;
								mdx.read(reinterpret_cast<char*>(&norm), sizeof(Vec3F));
								vertexNormals[geosetcount].push_back(norm);
							}
						}

						if (!strncmp(chunkheader2.tag, "PVTX", 4)) 
						{
							for (int i = 0; i < chunkheader2.size / 3; ++i)
							{
								triangle singletriangle;
								mdx.read(reinterpret_cast<char*>(&singletriangle), sizeof(triangle));
								singletriangle.indice1 += vertexcount;
								singletriangle.indice2 += vertexcount;
								singletriangle.indice3 += vertexcount;
								PrimitiveVertices[geosetcount].push_back(singletriangle);
							}
							vertexcount += vertexPositions[geosetcount].size();
						}

						if (!strncmp(chunkheader2.tag, "MATS", 4))
						{
							mdx.seekg((long)mdx.tellg() + (chunkheader2.size * sizeof(uint32)));
							uint32 materialid;
							mdx.read(reinterpret_cast<char*>(&materialid), sizeof(uint32));
							materialIds[geosetcount].push_back(materialid);

							mdx.seekg((long)mdx.tellg() + (sizeof(uint32) * 2));
							uint32 lod;
							mdx.read(reinterpret_cast<char*>(&lod), sizeof(uint32));
							lods[geosetcount] = lod;

							mdx.seekg((long)mdx.tellg() + (80 + sizeof(Extent)));
							uint32 extentcount;
							mdx.read(reinterpret_cast<char*>(&extentcount), sizeof(uint32));
							mdx.seekg((long)mdx.tellg() + (sizeof(Extent) * extentcount));
							long backpos = mdx.tellg();
							ChunkHeader skinheader;
							mdx.read(reinterpret_cast<char*>(&skinheader), sizeof(ChunkHeader));
							if (!strncmp(skinheader.tag, "TANG", 4))
							{
								mdx.seekg((long)mdx.tellg() + (skinheader.size * sizeof(float) * 4));
								backpos = mdx.tellg();
								mdx.read(reinterpret_cast<char*>(&skinheader), sizeof(ChunkHeader));
							}
							if (!strncmp(skinheader.tag, "SKIN", 4))
							{
								for (int i = 0; i < skinheader.size / 8; ++i)
								{
									Boneweight boneweight;
									mdx.read(reinterpret_cast<char*>(&boneweight), sizeof(Boneweight));
									boneweights[geosetcount].push_back(boneweight);
								}
							}
							else
							{
								mdx.seekg(backpos);
							}		
						}

						if (!strncmp(chunkheader2.tag, "UVAS", 4))
						{
							for (int i = 0; i < chunkheader2.size; ++i)
							{
								ChunkHeader uvbsheader;
								mdx.read(reinterpret_cast<char*>(&uvbsheader), sizeof(ChunkHeader));
								for (int i = 0; i < uvbsheader.size; ++i)
								{
									Vec2F texcord;
									mdx.read(reinterpret_cast<char*>(&texcord), sizeof(Vec2F));
									textureCoordinates[geosetcount].push_back(texcord);
								}
							}
						}

						if ((!strncmp(chunkheader2.tag, "PTYP", 4)) || (!strncmp(chunkheader2.tag, "MTGC", 4)) || (!strncmp(chunkheader2.tag, "PCNT", 4)))
							mdx.seekg((long)mdx.tellg() + (chunkheader2.size * sizeof(uint32)));
						if (!strncmp(chunkheader2.tag, "GNDX", 4))
							mdx.seekg((long)mdx.tellg() + (chunkheader2.size * sizeof(uint8)));
					}
					geosetcount++;
				}
			}

			if (!strncmp(chunkheader.tag, "BONE", 4))
			{
				int bonecount = 0;
				while (mdx.tellg() != (savepos + chunkheader.size))
				{
					Node node;
					long savepos2 = mdx.tellg();
					mdx.read(reinterpret_cast<char*>(&node), sizeof(Node));
					bones.push_back(node);

					while (mdx.tellg() != (savepos2 + node.inclusiveSize + (sizeof(uint32) * 2)))
					{
						TracksChunk trackheader;
						mdx.read(reinterpret_cast<char*>(&trackheader), sizeof(TracksChunk));

						if (!strncmp(trackheader.tag, "KGTR", 4))
						{
							for (int i = 0; i < trackheader.tracksCount; ++i)
							{
								KGTR kgtr;
								mdx.read(reinterpret_cast<char*>(&kgtr), sizeof(KGTR));
								KGTRs[bonecount].push_back(kgtr);
							}
						}
						else
						{
							if (!strncmp(trackheader.tag, "KGRT", 4))
							{
								for (int i = 0; i < trackheader.tracksCount; ++i)
								{
									KGRT kgrt;
									mdx.read(reinterpret_cast<char*>(&kgrt), sizeof(KGRT));
									KGRTs[bonecount].push_back(kgrt);	
								}
							}
							else
							{
								if (!strncmp(trackheader.tag, "KGSC", 4))
								{
									for (int i = 0; i < trackheader.tracksCount; ++i)
									{
										KGSC kgsc;
										mdx.read(reinterpret_cast<char*>(&kgsc), sizeof(KGSC));
										KGSCs[bonecount].push_back(kgsc);
									}
								}
								else
								{
									mdx.seekg(savepos2 + node.inclusiveSize + (sizeof(uint32) * 2));
								}
							}
						}
					}
					bonecount++;
				}
			}

			mdx.seekg(savepos + chunkheader.size, ios::beg);
		}

		for (int i = 0; i < materialIds.size(); ++i)
			for (int j = 0; j < materialIds[i].size(); ++j)
				for(int k = 0;k< layers[materialIds[i][j]].size();++k)
					geoslayers[i].push_back(layers[materialIds[i][j]][k]);
				
	}

	M2Data ToM2Data()
	{
		M2Data m2;

		uint16 startVertex = 0;
		uint16 startTriangle = 0;
		for (int i = 0; i < vertexPositions.size(); ++i)
		{
			submesh smesh;
			smesh.id = 0;
			smesh.startVertex = startVertex;
			smesh.nVertices = vertexPositions[i].size();
			smesh.startTriangle = startTriangle;
			if((PrimitiveVertices[i].size() * 3) > 65535)
				cout << "Triangle limit exceeded at Submesh " << i << endl;
			smesh.nTriangles = PrimitiveVertices[i].size() * 3;
			startVertex += vertexPositions[i].size();
			startTriangle += PrimitiveVertices[i].size() * 3;

			uint16 nBones = 0;
			for (int j = 0; j < boneweights[i].size(); ++j)
			{
				if (boneweights[i][j].boneIndex0 > nBones)
					nBones = boneweights[i][j].boneIndex0;
				if (boneweights[i][j].boneIndex1 > nBones)
					nBones = boneweights[i][j].boneIndex1;
				if (boneweights[i][j].boneIndex2 > nBones)
					nBones = boneweights[i][j].boneIndex2;
				if (boneweights[i][j].boneIndex3 > nBones)
					nBones = boneweights[i][j].boneIndex3;
			}

			smesh.nBones = nBones;
			smesh.StartBone = 0;
			smesh.BoneInfluences = 4;
			smesh.RootBone = 0;
			smesh.CenterMass.x = 0;
			smesh.CenterMass.y = 0;
			smesh.CenterMass.z = 0;
			smesh.CenterBoundingBox.x = 0;
			smesh.CenterBoundingBox.y = 0;
			smesh.CenterBoundingBox.z = 0;
			smesh.radius = 60;
			m2.submeshes.push_back(smesh);

			for (int j = 0; j < vertexPositions[i].size(); ++j)
			{
				vertex m2vertex;
				m2vertex.Position = vertexPositions[i][j];
				m2vertex.BoneWeight.BoneWeight0 = boneweights[i][j].weight0;
				m2vertex.BoneWeight.BoneWeight1 = boneweights[i][j].weight1;
				m2vertex.BoneWeight.BoneWeight2 = boneweights[i][j].weight2;
				m2vertex.BoneWeight.BoneWeight3 = boneweights[i][j].weight3;
				m2vertex.BoneIndices.BoneIndex0 = boneweights[i][j].boneIndex0;
				m2vertex.BoneIndices.BoneIndex1 = boneweights[i][j].boneIndex1;
				m2vertex.BoneIndices.BoneIndex2 = boneweights[i][j].boneIndex2;
				m2vertex.BoneIndices.BoneIndex3 = boneweights[i][j].boneIndex3;
				m2vertex.Normal = vertexNormals[i][j];
				m2vertex.TextureCoords = textureCoordinates[i][j];
				m2vertex.Unknown.x = 0;
				m2vertex.Unknown.y = 0;
				m2.vertices.push_back(m2vertex);
			}

			for (int j = 0; j < PrimitiveVertices[i].size(); ++j)
				m2.triangles.push_back(PrimitiveVertices[i][j]);	
		}

		for (int i = 0; i < sequences.size(); ++i)
		{
			animation singleAnim;
			string animname(sequences[i].name, end(sequences[i].name));
			singleAnim.AnimationID = M2AnimIDs[animname];
			singleAnim.SubAnimationID = 0;
			singleAnim.Length = ((sequences[i].interval[1] - sequences[i].interval[0]) / 30) * 1000;
			singleAnim.MovingSpeed = sequences[i].moveSpeed;
			if (sequences[i].flags == 1)
				singleAnim.Flags = 32 + 1;
			else
				singleAnim.Flags = 32;
			singleAnim.Probability = 32767;
			singleAnim.Unknown0 = 0;
			singleAnim.Unknown1 = 0;
			singleAnim.Unknown2 = 0;
			singleAnim.PlaybackSpeed = 150;
			singleAnim.BoundRadius = 0;
			singleAnim.NextAnimation = -1;
			singleAnim.Index = i;
			m2.animations.push_back(singleAnim);
		}

		for (int i = 0; i < bones.size(); ++i)
		{
			m2bone singleM2bone;
			singleM2bone.KeyBoneId = -1;
			singleM2bone.Flags = 0;
			singleM2bone.ParentBone = bones[i].parentId;
			singleM2bone.Unknown[0] = 0;
			singleM2bone.Unknown[1] = 0;
			singleM2bone.Unknown[2] = 0;

			if (KGTRs[i].size() != 0)
			{
				singleM2bone.Translation.InterpolationType = 1;
				singleM2bone.Translation.GlobalSequenceID = -1;
				singleM2bone.Translation.numberOfTimestampPairs = sequences.size();
				singleM2bone.Translation.offsetToTimestampPairs = 0;
				singleM2bone.Translation.numberOfKeyFramePairs = sequences.size();
				singleM2bone.Translation.offsetToKeyFramePairs = 0;
			}
			else
			{
				singleM2bone.Translation.InterpolationType = 0;
				singleM2bone.Translation.GlobalSequenceID = -1;
				singleM2bone.Translation.numberOfTimestampPairs = 0;
				singleM2bone.Translation.offsetToTimestampPairs = 0;
				singleM2bone.Translation.numberOfKeyFramePairs = 0;
				singleM2bone.Translation.offsetToKeyFramePairs = 0;
			}

			if (KGRTs[i].size() != 0)
			{
				singleM2bone.Rotation.InterpolationType = 1;
				singleM2bone.Rotation.GlobalSequenceID = -1;
				singleM2bone.Rotation.numberOfTimestampPairs = sequences.size();
				singleM2bone.Rotation.offsetToTimestampPairs = 0;
				singleM2bone.Rotation.numberOfKeyFramePairs = sequences.size();
				singleM2bone.Rotation.offsetToKeyFramePairs = 0;
			}
			else
			{
				singleM2bone.Rotation.InterpolationType = 0;
				singleM2bone.Rotation.GlobalSequenceID = -1;
				singleM2bone.Rotation.numberOfTimestampPairs = 0;
				singleM2bone.Rotation.offsetToTimestampPairs = 0;
				singleM2bone.Rotation.numberOfKeyFramePairs = 0;
				singleM2bone.Rotation.offsetToKeyFramePairs = 0;
			}

			if (KGSCs[i].size() != 0)
			{
				singleM2bone.Scaling.InterpolationType = 1;
				singleM2bone.Scaling.GlobalSequenceID = -1;
				singleM2bone.Scaling.numberOfTimestampPairs = sequences.size();
				singleM2bone.Scaling.offsetToTimestampPairs = 0;
				singleM2bone.Scaling.numberOfKeyFramePairs = sequences.size();
				singleM2bone.Scaling.offsetToKeyFramePairs = 0;
			}
			else
			{
				singleM2bone.Scaling.InterpolationType = 0;
				singleM2bone.Scaling.GlobalSequenceID = -1;
				singleM2bone.Scaling.numberOfTimestampPairs = 0;
				singleM2bone.Scaling.offsetToTimestampPairs = 0;
				singleM2bone.Scaling.numberOfKeyFramePairs = 0;
				singleM2bone.Scaling.offsetToKeyFramePairs = 0;
			}

			singleM2bone.PivotPoint = PivotPoints[i];
			m2.m2bones.push_back(singleM2bone);
		}


		for (int i = 0; i < bones.size(); ++i)
		{
			for (int j = 0; j < sequences.size(); ++j)
			{
				// assorted by anim and bone
				vector<KGTR> AnimKGTRs;
				vector<KGRT> AnimKGRTs;
				vector<KGSC> AnimKGSCs;
				for (int k = 0; k < KGTRs[i].size(); ++k)
					if ((KGTRs[i][k].frame > sequences[j].interval[0]) && (KGTRs[i][k].frame < sequences[j].interval[1]))
						AnimKGTRs.push_back(KGTRs[i][k]);
				for (int k = 0; k < KGRTs[i].size(); ++k)
					if ((KGRTs[i][k].frame > sequences[j].interval[0]) && (KGRTs[i][k].frame < sequences[j].interval[1]))
						AnimKGRTs.push_back(KGRTs[i][k]);
				for (int k = 0; k < KGSCs[i].size(); ++k)
					if ((KGSCs[i][k].frame > sequences[j].interval[0]) && (KGSCs[i][k].frame < sequences[j].interval[1]))
						AnimKGSCs.push_back(KGSCs[i][k]);

				m2SubABlock Ttimestampanimblock;
				m2SubABlock Rtimestampanimblock;
				m2SubABlock Stimestampanimblock;
				m2SubABlock Tvalueanimblock;
				m2SubABlock Rvalueanimblock;
				m2SubABlock Svalueanimblock;

				if (KGTRs[i].size() != 0)
				{
					Ttimestampanimblock.nValues = AnimKGTRs.size();
					Ttimestampanimblock.ofsValues = 0;
					Tvalueanimblock.nValues = AnimKGTRs.size();
					Tvalueanimblock.ofsValues = 0;
					m2.Ttimestampanimblocks.push_back(Ttimestampanimblock);
					m2.Tvalueanimblocks.push_back(Tvalueanimblock);

					for (int k = 0; k < AnimKGTRs.size(); ++k)
					{
						uint32 Ttimestamp = (AnimKGTRs[k].frame / 30) * 1000;
						Vec3F translation = AnimKGTRs[k].translation;
						m2.Ttimestamps.push_back(Ttimestamp);
						m2.translations.push_back(translation);
					}
				}

				if (KGRTs[i].size() != 0)
				{
					Rtimestampanimblock.nValues = AnimKGRTs.size();
					Rtimestampanimblock.ofsValues = 0;
					Rvalueanimblock.nValues = AnimKGRTs.size();
					Rvalueanimblock.ofsValues = 0;
					m2.Rtimestampanimblocks.push_back(Rtimestampanimblock);
					m2.Rvalueanimblocks.push_back(Rvalueanimblock);

					for (int k = 0; k < AnimKGRTs.size(); ++k)
					{
						uint32 Rtimestamp = (AnimKGRTs[k].frame / 30) * 1000;
						Vec4Short rotation;
						rotation.x = (AnimKGRTs[k].rotation.x + 1.0f) * 32767;
						rotation.y = (AnimKGRTs[k].rotation.y + 1.0f) * 32767;
						rotation.z = (AnimKGRTs[k].rotation.z + 1.0f) * 32767;
						rotation.w = (AnimKGRTs[k].rotation.w + 1.0f) * 32767;
						m2.Rtimestamps.push_back(Rtimestamp);
						m2.rotations.push_back(rotation);
					}
				}
		
				if (KGSCs[i].size() != 0)
				{
					Stimestampanimblock.nValues = AnimKGSCs.size();
					Stimestampanimblock.ofsValues = 0;
					Svalueanimblock.nValues = AnimKGSCs.size();
					Svalueanimblock.ofsValues = 0;
					m2.Stimestampanimblocks.push_back(Stimestampanimblock);
					m2.Svalueanimblocks.push_back(Svalueanimblock);

					for (int k = 0; k < AnimKGSCs.size(); ++k)
					{
						uint32 Stimestamp = (AnimKGSCs[k].frame / 30) * 1000;
						Vec3F scale = AnimKGSCs[k].scale;
						m2.Stimestamps.push_back(Stimestamp);
						m2.scales.push_back(scale);
					}
				}
			}
		}

		// fill AnimationLookup
		for (int i = 0; i < m2.highestanimid() + 1; ++i)
		{
			int16 animlookup = -1;
			for (int j = 0; j < m2.animations.size(); ++j)
			{
				if (m2.animations[j].AnimationID == i)
				{
					animlookup = i;
					break;
				}
			}

			m2.AnimationLookup.push_back(animlookup);
		}

		if (m2.AnimationLookup.size() == 1) // if there is only one lookup, the m2 will crash ingame
		{
			m2.AnimationLookup.push_back(-1);
		}

		for (int i = 0; i < m2.m2bones.size(); ++i)
			m2.BoneLookupTable.push_back(i);

		for (int i = 0; i < 27; ++i)
		{
			int16 keybone = -1;
			m2.KeyBoneLookups.push_back(keybone);
		}

		for (int i = 0; i < textures.size(); ++i)
		{
			m2texture singlem2texture;
			singlem2texture.Flags = 0;
			singlem2texture.Type = 0;
			m2.m2textures.push_back(singlem2texture);
			m2.texloclist.push_back(textures[i].fileName);
			m2.TexLookupTable.push_back(i);
		}

		for (uint16 i = 0; i < m2.vertices.size(); ++i)
			m2.skinIndices.push_back(i);

		for (int i = 0; i < geoslayers.size(); ++i)
		{
			for (int j = 0; j < geoslayers[i].size(); ++j)
			{
				TextureUnit texUnit;

				texUnit.flags = 16;
				texUnit.shading = 0;
				texUnit.submeshIndex = i;
				texUnit.submeshIndex2 = i;
				texUnit.colorIndex = -1;
				texUnit.renderFlag = 0;
				texUnit.texUnitNumber = 0;
				texUnit.mode = 1;
				texUnit.texture = geoslayers[i][j].textureId;
				texUnit.texUnitNumber2 = 0;
				texUnit.transparency = 0;
				texUnit.textureAnim = 0;

				m2.TextureUnits.push_back(texUnit);
			}
		}

		return m2;
	}
};
