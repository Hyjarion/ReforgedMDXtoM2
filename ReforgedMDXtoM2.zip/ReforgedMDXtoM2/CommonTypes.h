typedef unsigned char uint8;
typedef unsigned __int16 uint16;
typedef __int16 int16;
typedef unsigned __int32 uint32;
typedef __int32 int32;

struct Vec4Short
{
	uint16 x;
	uint16 y;
	uint16 z;
	uint16 w;
};

struct Vec4F
{
	float x;
	float y;
	float z;
	float w;
};

struct Vec3F
{
	float x;
	float y;
	float z;
};

struct Vec2F
{
	float x;
	float y;
};
