// Made by Highlord

#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <algorithm>
#include "CommonTypes.h"
#include "M2.h"
#include "MDX.h"

int main(int argc, char **argv)
{
	MDXdata mdata;
	mdata.FillDataFromMDX(argv[1]);
	M2Data m2data = mdata.ToM2Data();

	string filename = argv[1];
	filename = filename.substr(0, filename.size() - 4);

	m2data.BuildM2(filename);
	m2data.BuildSkin(filename);

	cin.get();
}
