using namespace std;

struct M2header
{
	char Magic[4];
	uint32 Version;
	uint32 lName;
	uint32 ofsName;
	uint32 GlobalModelFlags;

	uint32 nGlobalSequences;
	uint32 ofsGlobalSequences;
	uint32 nAnimations;
	uint32 ofsAnimations;
	uint32 nAnimationLookup;
	uint32 ofsAnimationLookup;
	uint32 nBones;
	uint32 ofsBones;
	uint32 nKeyBoneLookup;
	uint32 ofsKeyBoneLookup;

	uint32 nVertices;
	uint32 ofsVertices;
	uint32 nViews;

	uint32 nColors;
	uint32 ofsColors;

	uint32 nTextures;
	uint32 ofsTextures;

	uint32 nTransparency;
	uint32 ofsTransparency;
	uint32 nTexAnims;
	uint32 ofsTexAnims;
	uint32 nTexReplace;
	uint32 ofsTexReplace;

	uint32 nRenderFlags;
	uint32 ofsRenderFlags;
	uint32 nBoneLookupTable;
	uint32 ofsBoneLookupTable;

	uint32 nTexLookup;
	uint32 ofsTexLookup;

	uint32 nTexUnitLookup;
	uint32 ofsTexUnitLookup;
	uint32 nTransparencyLookup;
	uint32 ofsTransparencyLookup;
	uint32 nTexAnimLookup;
	uint32 ofsTexAnimLookup;

	Vec3F VertexBoxMin;
	Vec3F VertexBoxMax;
	float VertexBoxRadius;
	Vec3F BoundingBoxMin;
	Vec3F BoundingBoxMax;
	float BoundingBoxRadius;

	uint32 nBoundingTriangles;
	uint32 ofsBoundingTriangles;
	uint32 nBoundingVertices;
	uint32 ofsBoundingVertices;
	uint32 nBoundingNormals;
	uint32 ofsBoundingNormals;

	uint32 nAttachments;
	uint32 ofsAttachments;
	uint32 nAttachLookup;
	uint32 ofsAttachLookup;
	uint32 nEvents;
	uint32 ofsEvents;
	uint32 nLights;
	uint32 ofsLights;
	uint32 nCameras;
	uint32 ofsCameras;
	uint32 nCameraLookup;
	uint32 ofsCameraLookup;
	uint32 nRibbonEmitters;
	uint32 ofsRibbonEmitters;
	uint32 nParticleEmitters;
	uint32 ofsParticleEmitters;
};


struct m2ABlock
{
	uint16 InterpolationType;
	uint16 GlobalSequenceID;
	uint32 numberOfTimestampPairs;
	uint32 offsetToTimestampPairs;
	uint32 numberOfKeyFramePairs;
	uint32 offsetToKeyFramePairs;
};

struct m2SubABlock
{
	int32 nValues;
	int32 ofsValues;
};

struct m2bone
{
	int32 KeyBoneId;
	uint32 Flags;
	int16 ParentBone;
	uint16 Unknown[3];
	m2ABlock Translation;
	m2ABlock Rotation;
	m2ABlock Scaling;
	Vec3F PivotPoint;
};

struct m2transparency
{
	m2ABlock Transparency;
};

struct m2texture
{
	uint32 Type;
	uint32 Flags;
	uint32 Filename_lenght;
	uint32 Filename_offset;
};

struct animation
{
	uint16 AnimationID;
	uint16 SubAnimationID;
	uint32 Length;
	float MovingSpeed;
	uint32 Flags;
	int16 Probability;
	uint16 Unknown0;
	uint32 Unknown1;
	uint32 Unknown2;
	uint32 PlaybackSpeed;
	Vec3F BoundingBoxMin;
	Vec3F BoundingBoxMax;
	float BoundRadius;
	int16 NextAnimation;
	uint16 Index;
};

struct renderFlag
{
	uint16 Flags;
	uint16 Blending;
};

struct WeightBone
{
	uint8 BoneWeight0;
	uint8 BoneWeight1;
	uint8 BoneWeight2;
	uint8 BoneWeight3;
};

struct IndicesBone
{
	uint8 BoneIndex0;
	uint8 BoneIndex1;
	uint8 BoneIndex2;
	uint8 BoneIndex3;
};

struct vertex
{
	Vec3F Position;
	WeightBone BoneWeight;
	IndicesBone BoneIndices;
	Vec3F Normal;
	Vec2F TextureCoords;
	Vec2F Unknown;
};

// Skin struct

struct skinheader
{
	char id[4];
	uint32 nIndices;
	uint32 ofsIndices;
	uint32 nTriangles;
	uint32 ofsTriangles;
	uint32 nProperties;
	uint32 ofsProperties;
	uint32 nSubmeshes;
	uint32 ofsSubmeshes;
	uint32 nTextureUnits;
	uint32 ofsTextureUnits;
	uint32 LOD;
};

struct triangle
{
	uint16 indice1;
	uint16 indice2;
	uint16 indice3;
};

struct submesh
{
	uint32 id;
	uint16 startVertex;
	uint16 nVertices;
	uint16 startTriangle;
	uint16 nTriangles;
	uint16 nBones;
	uint16 StartBone;
	uint16 BoneInfluences;
	uint16 RootBone;
	Vec3F CenterMass;
	Vec3F CenterBoundingBox;
	float radius;
};

struct TextureUnit
{
	uint16 flags;
	uint16 shading;
	uint16 submeshIndex;
	uint16 submeshIndex2;
	int16 colorIndex;
	uint16 renderFlag;
	uint16 texUnitNumber;
	uint16 mode;
	uint16 texture;
	uint16 texUnitNumber2;
	uint16 transparency;
	uint16 textureAnim;
};

struct M2Attachment
{
	uint32 id;
	uint16 bone;
	uint16 unknown;
	Vec3F position;
	m2ABlock data;
};

struct M2Camera
{
	uint32 type;
	float fov;
	float far_clip;
	float near_clip;
	m2ABlock positions;
	Vec3F position_base;
	m2ABlock target_positions;
	Vec3F target_position_base;
	m2ABlock rolldata;
};

class M2Data
{
public:
	std::vector<std::string> texloclist;

	std::vector<submesh> submeshes;
	std::vector<animation> animations;
	std::vector<m2bone> m2bones;

	std::vector<m2SubABlock> Ttimestampanimblocks;
	std::vector<m2SubABlock> Rtimestampanimblocks;
	std::vector<m2SubABlock> Stimestampanimblocks;
	std::vector<uint32> Ttimestamps;
	std::vector<uint32> Rtimestamps;
	std::vector<uint32> Stimestamps;
	std::vector<m2SubABlock> Tvalueanimblocks;
	std::vector<m2SubABlock> Rvalueanimblocks;
	std::vector<m2SubABlock> Svalueanimblocks;
	std::vector<Vec3F> translations;
	std::vector<Vec4Short> rotations;
	std::vector<Vec3F> scales;

	std::vector<int16> AnimationLookup;
	std::vector<int16> BoneLookupTable;
	std::vector<int16> KeyBoneLookups;
	std::vector<m2texture> m2textures;
	std::vector<vertex> vertices;
	std::vector<triangle> triangles;
	std::vector<int16> TexLookupTable;

	std::vector<uint16> skinIndices;
	std::vector<TextureUnit> TextureUnits;
	std::vector<Vec3F> BoundingNormals;
	std::vector<M2Attachment> attachments;
	std::vector<int16> AttachmentLookup;

	uint32 highestanimid()
	{
		uint32 highest = 0;
		for (int i = 0; i < animations.size(); ++i)
		{
			if (animations[i].AnimationID > highest)
				highest = animations[i].AnimationID;
		}

		return highest;
	}

	void BuildM2(string filename)
	{
		string m2name = filename;

		ofstream m2stream;
		filename.append(".m2");
		m2stream.open(filename, std::ios::binary);

		M2header header;

		uint32 offset = sizeof(M2header);

		header.Magic[0] = 'M';
		header.Magic[1] = 'D';
		header.Magic[2] = '2';
		header.Magic[3] = '0';
		header.Version = 264;
		header.lName = m2name.length() + 1;
		header.ofsName = offset;
		offset += m2name.length() + 1;
		header.GlobalModelFlags = 0;
		header.nGlobalSequences = 0;
		header.ofsGlobalSequences = 0;
		header.nAnimations = animations.size();
		header.ofsAnimations = offset;
		offset += animations.size() * sizeof(animation);
		header.nAnimationLookup = AnimationLookup.size();
		header.ofsAnimationLookup = offset;
		offset += AnimationLookup.size() * sizeof(int16);
		header.nBones = m2bones.size();
		header.ofsBones = offset;
		offset += m2bones.size() * sizeof(m2bone);

		// finish bones with offsets
		if (animations.size() > 0)
		{
			for (int i = 0; i < m2bones.size(); ++i)
			{
				if (m2bones[i].Translation.numberOfTimestampPairs > 0)
				{
					m2bones[i].Translation.offsetToTimestampPairs = offset;
					offset += m2bones[i].Translation.numberOfTimestampPairs * sizeof(m2SubABlock);
				}
			}

			for (int i = 0; i < m2bones.size(); ++i)
			{
				if (m2bones[i].Rotation.numberOfTimestampPairs > 0)
				{
					m2bones[i].Rotation.offsetToTimestampPairs = offset;
					offset += m2bones[i].Rotation.numberOfTimestampPairs * sizeof(m2SubABlock);
				}
			}

			for (int i = 0; i < m2bones.size(); ++i)
			{
				if (m2bones[i].Scaling.numberOfTimestampPairs > 0)
				{
					m2bones[i].Scaling.offsetToTimestampPairs = offset;
					offset += m2bones[i].Scaling.numberOfTimestampPairs * sizeof(m2SubABlock);
				}
			}

			for (int i = 0; i < m2bones.size(); ++i)
			{
				if (m2bones[i].Translation.numberOfKeyFramePairs > 0)
				{
					m2bones[i].Translation.offsetToKeyFramePairs = offset;
					offset += m2bones[i].Translation.numberOfKeyFramePairs * sizeof(m2SubABlock);
				}
			}

			for (int i = 0; i < m2bones.size(); ++i)
			{
				if (m2bones[i].Rotation.numberOfKeyFramePairs > 0)
				{
					m2bones[i].Rotation.offsetToKeyFramePairs = offset;
					offset += m2bones[i].Rotation.numberOfKeyFramePairs * sizeof(m2SubABlock);
				}
			}

			for (int i = 0; i < m2bones.size(); ++i)
			{
				if (m2bones[i].Scaling.numberOfKeyFramePairs > 0)
				{
					m2bones[i].Scaling.offsetToKeyFramePairs = offset;
					offset += m2bones[i].Scaling.numberOfKeyFramePairs * sizeof(m2SubABlock);
				}
			}

			for (int i = 0; i < Ttimestampanimblocks.size(); ++i)
			{
				if (Ttimestampanimblocks[i].nValues > 0)
				{
					Ttimestampanimblocks[i].ofsValues = offset;
					offset += Ttimestampanimblocks[i].nValues * sizeof(uint32);
				}
			}

			for (int i = 0; i < Rtimestampanimblocks.size(); ++i)
			{
				if (Rtimestampanimblocks[i].nValues > 0)
				{
					Rtimestampanimblocks[i].ofsValues = offset;
					offset += Rtimestampanimblocks[i].nValues * sizeof(uint32);
				}
			}

			for (int i = 0; i < Stimestampanimblocks.size(); ++i)
			{
				if (Stimestampanimblocks[i].nValues > 0)
				{
					Stimestampanimblocks[i].ofsValues = offset;
					offset += Stimestampanimblocks[i].nValues * sizeof(uint32);
				}
			}

			for (int i = 0; i < Tvalueanimblocks.size(); ++i)
			{
				if (Tvalueanimblocks[i].nValues > 0)
				{
					Tvalueanimblocks[i].ofsValues = offset;
					offset += Tvalueanimblocks[i].nValues * sizeof(Vec3F);
				}
			}

			for (int i = 0; i < Rvalueanimblocks.size(); ++i)
			{
				if (Rvalueanimblocks[i].nValues > 0)
				{
					Rvalueanimblocks[i].ofsValues = offset;
					offset += Rvalueanimblocks[i].nValues * sizeof(Vec4Short);
				}
			}

			for (int i = 0; i < Svalueanimblocks.size(); ++i)
			{
				if (Svalueanimblocks[i].nValues > 0)
				{
					Svalueanimblocks[i].ofsValues = offset;
					offset += Svalueanimblocks[i].nValues * sizeof(Vec3F);
				}
			}
		}

		header.nKeyBoneLookup = 27;
		header.ofsKeyBoneLookup = offset;
		offset += 27 * sizeof(int16);
		header.nVertices = vertices.size();
		header.ofsVertices = offset;
		offset += vertices.size() * sizeof(vertex);
		header.nViews = 1;
		header.nColors = 0;
		header.ofsColors = 0;
		header.nTextures = texloclist.size();
		header.ofsTextures = offset;
		offset += texloclist.size() * sizeof(m2texture);

		for (int i = 0; i < texloclist.size(); ++i)
		{
			m2textures[i].Filename_lenght = texloclist[i].length();
			m2textures[i].Filename_offset = offset;
			offset += texloclist[i].length() + 1;
		}

		header.nTransparency = 1;
		header.ofsTransparency = offset;
		offset += sizeof(m2ABlock);

		m2ABlock transblock;
		m2SubABlock transblocksub[2];
		uint32 timestamp = 0;
		uint16 anim = 32767;

		transblock.InterpolationType = 0;
		transblock.GlobalSequenceID = -1;
		transblock.numberOfTimestampPairs = 1;
		transblock.numberOfKeyFramePairs = 1;
		transblock.offsetToTimestampPairs = offset;
		offset += sizeof(m2SubABlock);
		transblock.offsetToKeyFramePairs = offset;
		offset += sizeof(m2SubABlock);

		transblocksub[0].nValues = 1;
		transblocksub[0].ofsValues = offset;
		offset += sizeof(uint32);

		transblocksub[1].nValues = 1;
		transblocksub[1].ofsValues = offset;
		offset += sizeof(uint16);

		header.nTexAnims = 0;
		header.ofsTexAnims = 0;
		header.nTexReplace = 1;
		header.ofsTexReplace = offset;
		offset += sizeof(int16);
		header.nRenderFlags = 1;
		header.ofsRenderFlags = offset;
		offset += sizeof(renderFlag);

		for (int i = 0; i < m2bones.size(); ++i)
			BoneLookupTable.push_back(i);

		header.nBoneLookupTable = BoneLookupTable.size();
		header.ofsBoneLookupTable = offset;
		offset += BoneLookupTable.size() * sizeof(int16);
		header.nTexLookup = m2textures.size();
		header.ofsTexLookup = offset;
		offset += m2textures.size() * sizeof(int16);
		header.nTexUnitLookup = 1;
		header.ofsTexUnitLookup = offset;
		offset += sizeof(int16);
		header.nTransparencyLookup = 1;
		header.ofsTransparencyLookup = offset;
		offset += sizeof(int16);
		header.nTexAnimLookup = 1;
		header.ofsTexAnimLookup = offset;
		offset += sizeof(int16);


		header.VertexBoxMax.x = 0;
		header.VertexBoxMax.y = 0;
		header.VertexBoxMax.z = 0;
		header.VertexBoxMin.x = 0;
		header.VertexBoxMin.y = 0;
		header.VertexBoxMin.z = 0;
		for (int i = 0; i < vertices.size(); ++i)  // thanks to Garthog
		{
			if (vertices[i].Position.x > header.VertexBoxMax.x)
				header.VertexBoxMax.x = vertices[i].Position.x;
			if (vertices[i].Position.y > header.VertexBoxMax.y)
				header.VertexBoxMax.y = vertices[i].Position.y;
			if (vertices[i].Position.z > header.VertexBoxMax.z)
				header.VertexBoxMax.z = vertices[i].Position.z;

			if (vertices[i].Position.x < header.VertexBoxMin.x)
				header.VertexBoxMin.x = vertices[i].Position.x;
			if (vertices[i].Position.y < header.VertexBoxMin.y)
				header.VertexBoxMin.y = vertices[i].Position.y;
			if (vertices[i].Position.z < header.VertexBoxMin.z)
				header.VertexBoxMin.z = vertices[i].Position.z;
		}
		float boxminlength = sqrtf((header.VertexBoxMin.x * header.VertexBoxMin.x) + (header.VertexBoxMin.y * header.VertexBoxMin.y) + (header.VertexBoxMin.z * header.VertexBoxMin.z));
		float boxmaxlength = sqrtf((header.VertexBoxMax.x * header.VertexBoxMax.x) + (header.VertexBoxMax.y * header.VertexBoxMax.y) + (header.VertexBoxMax.z * header.VertexBoxMax.z));
		header.VertexBoxRadius = (boxminlength + boxmaxlength) / 2;

		header.BoundingBoxMax.x = header.VertexBoxMax.x;
		header.BoundingBoxMax.y = header.VertexBoxMax.y;
		header.BoundingBoxMax.z = header.VertexBoxMax.z;
		header.BoundingBoxMin.x = header.VertexBoxMin.x;
		header.BoundingBoxMin.y = header.VertexBoxMin.y;
		header.BoundingBoxMin.z = header.VertexBoxMin.z;
		header.BoundingBoxRadius = header.VertexBoxRadius;

		bool needcollision;
		cout << "Do you need collision ?\n";
		cin >> needcollision;

		if (needcollision)
		{
			header.nBoundingTriangles = triangles.size() * 3;
			header.ofsBoundingTriangles = offset;
			offset += sizeof(triangle) * triangles.size();
			header.nBoundingVertices = vertices.size();
			header.ofsBoundingVertices = offset;
			offset += sizeof(Vec3F) * vertices.size();

			// thanks to Mjollna
			for (int i = 0; i < triangles.size(); ++i)
			{
				Vec3F U;
				U.x = vertices[triangles[i].indice2].Position.x - vertices[triangles[i].indice1].Position.x;
				U.y = vertices[triangles[i].indice2].Position.y - vertices[triangles[i].indice1].Position.y;
				U.z = vertices[triangles[i].indice2].Position.z - vertices[triangles[i].indice1].Position.z;

				Vec3F V;
				V.x = vertices[triangles[i].indice3].Position.x - vertices[triangles[i].indice1].Position.x;
				V.y = vertices[triangles[i].indice3].Position.y - vertices[triangles[i].indice1].Position.y;
				V.z = vertices[triangles[i].indice3].Position.z - vertices[triangles[i].indice1].Position.z;

				Vec3F normal;
				normal.x = U.y * V.z - U.z * V.y;
				normal.y = U.z * V.x - U.x * V.z;
				normal.z = U.x * V.y - U.y * V.x;

				float normlength = sqrtf((normal.x * normal.x) + (normal.y * normal.y) + (normal.z * normal.z));
				normal.x = normal.x / normlength;
				normal.y = normal.y / normlength;
				normal.z = normal.z / normlength;

				BoundingNormals.push_back(normal);
			}

			header.nBoundingNormals = BoundingNormals.size();
			header.ofsBoundingNormals = offset;
			offset += sizeof(Vec3F) * BoundingNormals.size();
		}
		else
		{
			header.nBoundingTriangles = 0;
			header.ofsBoundingTriangles = 0;
			header.nBoundingVertices = 0;
			header.ofsBoundingVertices = 0;
			header.nBoundingNormals = 0;
			header.ofsBoundingNormals = 0;
		}

		header.nAttachments = attachments.size();
		header.ofsAttachments = offset;
		offset += sizeof(M2Attachment) * attachments.size();

		// finish attachments with offsets
		vector<m2SubABlock> attachTAblocks;
		vector<m2SubABlock> attachVAblocks;
		vector<uint32> attachtimestamps;
		vector<int> attachvalues;

		for (int i = 0; i < attachments.size(); ++i)
		{
			attachments[i].data.offsetToTimestampPairs = offset;
			offset += sizeof(m2SubABlock);
		}

		for (int i = 0; i < attachments.size(); ++i)
		{
			m2SubABlock attachTAblock;
			uint32 attachtimestamp = 0;

			attachTAblock.nValues = 1;
			attachTAblock.ofsValues = offset;
			offset += sizeof(uint32);
			attachTAblocks.push_back(attachTAblock);
			attachtimestamps.push_back(attachtimestamp);
		}

		for (int i = 0; i < attachments.size(); ++i)
		{
			attachments[i].data.offsetToKeyFramePairs = offset;
			offset += sizeof(m2SubABlock);
		}

		for (int i = 0; i < attachments.size(); ++i)
		{
			m2SubABlock attachVAblock;
			int animate_attached = 1;

			attachVAblock.nValues = 1;
			attachVAblock.ofsValues = offset;
			offset += sizeof(int);
			attachVAblocks.push_back(attachVAblock);
			attachvalues.push_back(animate_attached);
		}

		AttachmentLookup.push_back(-1); 

		header.nAttachLookup = AttachmentLookup.size();
		header.ofsAttachLookup = offset;
		offset += sizeof(int16) * AttachmentLookup.size();
		header.nEvents = 0;
		header.ofsEvents = 0;
		header.nLights = 0;
		header.ofsLights = 0;
		header.nCameras = 0;
		header.ofsCameras = 0;
		header.nCameraLookup = 0;
		header.ofsCameraLookup = 0;
		header.nRibbonEmitters = 0;
		header.ofsRibbonEmitters = 0;
		header.nParticleEmitters = 0;
		header.ofsParticleEmitters = 0;

		// start writing
		m2stream.write(reinterpret_cast<char*>(&header), sizeof(M2header));
		m2stream.write(m2name.c_str(), m2name.length() + 1);

		for (int i = 0; i < animations.size(); ++i)
		{
			animations[i].BoundingBoxMin.x = header.BoundingBoxMin.x;
			animations[i].BoundingBoxMin.y = header.BoundingBoxMin.y;
			animations[i].BoundingBoxMin.z = header.BoundingBoxMin.z;
			animations[i].BoundingBoxMax.x = header.BoundingBoxMax.x;
			animations[i].BoundingBoxMax.y = header.BoundingBoxMax.y;
			animations[i].BoundingBoxMax.z = header.BoundingBoxMax.z;
			animations[i].BoundRadius = header.BoundingBoxRadius;
		}

		m2stream.write(reinterpret_cast<char*>(&animations[0]), sizeof(animation) * animations.size());
		m2stream.write(reinterpret_cast<char*>(&AnimationLookup[0]), sizeof(int16) * AnimationLookup.size());
		m2stream.write(reinterpret_cast<char*>(&m2bones[0]), sizeof(m2bone) * m2bones.size());

		if (animations.size() > 0)
		{
			if (Ttimestampanimblocks.size() > 0)
				m2stream.write(reinterpret_cast<char*>(&Ttimestampanimblocks[0]), sizeof(m2SubABlock) * Ttimestampanimblocks.size());
			if (Rtimestampanimblocks.size() > 0)
				m2stream.write(reinterpret_cast<char*>(&Rtimestampanimblocks[0]), sizeof(m2SubABlock) * Rtimestampanimblocks.size());
			if (Stimestampanimblocks.size() > 0)
				m2stream.write(reinterpret_cast<char*>(&Stimestampanimblocks[0]), sizeof(m2SubABlock) * Stimestampanimblocks.size());
			if (Tvalueanimblocks.size() > 0)
				m2stream.write(reinterpret_cast<char*>(&Tvalueanimblocks[0]), sizeof(m2SubABlock) * Tvalueanimblocks.size());
			if (Rvalueanimblocks.size() > 0)
				m2stream.write(reinterpret_cast<char*>(&Rvalueanimblocks[0]), sizeof(m2SubABlock) * Rvalueanimblocks.size());
			if (Svalueanimblocks.size() > 0)
				m2stream.write(reinterpret_cast<char*>(&Svalueanimblocks[0]), sizeof(m2SubABlock) * Svalueanimblocks.size());
			if (Ttimestamps.size() > 0)
				m2stream.write(reinterpret_cast<char*>(&Ttimestamps[0]), sizeof(uint32) * Ttimestamps.size());
			if (Rtimestamps.size() > 0)
				m2stream.write(reinterpret_cast<char*>(&Rtimestamps[0]), sizeof(uint32) * Rtimestamps.size());
			if (Stimestamps.size() > 0)
				m2stream.write(reinterpret_cast<char*>(&Stimestamps[0]), sizeof(uint32) * Stimestamps.size());
			if (translations.size() > 0)
				m2stream.write(reinterpret_cast<char*>(&translations[0]), sizeof(Vec3F) * translations.size());
			if (rotations.size() > 0)
				m2stream.write(reinterpret_cast<char*>(&rotations[0]), sizeof(Vec4Short) * rotations.size());
			if (scales.size() > 0)
				m2stream.write(reinterpret_cast<char*>(&scales[0]), sizeof(Vec3F) * scales.size());
		}

		m2stream.write(reinterpret_cast<char*>(&KeyBoneLookups[0]), sizeof(int16) * KeyBoneLookups.size());

		m2stream.write(reinterpret_cast<char*>(&vertices[0]), sizeof(vertex) * vertices.size());
		m2stream.write(reinterpret_cast<char*>(&m2textures[0]), sizeof(m2texture) * m2textures.size());

		for (int i = 0; i < texloclist.size(); ++i)
		{
			m2stream.write(texloclist[i].c_str(), texloclist[i].length() + 1);
		}

		m2stream.write(reinterpret_cast<char*>(&transblock), sizeof(m2ABlock));
		m2stream.write(reinterpret_cast<char*>(transblocksub), sizeof(m2SubABlock) * 2);
		m2stream.write(reinterpret_cast<char*>(&timestamp), sizeof(uint32));
		m2stream.write(reinterpret_cast<char*>(&anim), sizeof(uint16));

		uint16 TexReplace = 1;
		m2stream.write(reinterpret_cast<char*>(&TexReplace), sizeof(uint16));

		renderFlag rflag;
		rflag.Flags = 0;
		rflag.Blending = 0;

		m2stream.write(reinterpret_cast<char*>(&rflag), sizeof(renderFlag));
		m2stream.write(reinterpret_cast<char*>(&BoneLookupTable[0]), sizeof(int16) * BoneLookupTable.size());

		m2stream.write(reinterpret_cast<char*>(&TexLookupTable[0]), sizeof(int16) * TexLookupTable.size());

		int16 texunitlookup = 0;
		m2stream.write(reinterpret_cast<char*>(&texunitlookup), sizeof(int16));

		int16 translookup = 0;
		m2stream.write(reinterpret_cast<char*>(&translookup), sizeof(int16));

		int16 texanimlookup = -1;
		m2stream.write(reinterpret_cast<char*>(&texanimlookup), sizeof(int16));


		if (needcollision)
		{
			m2stream.write(reinterpret_cast<char*>(&triangles[0]), sizeof(triangle) * triangles.size());
			m2stream.write(reinterpret_cast<char*>(&vertices[0]), sizeof(Vec3F) * vertices.size());
			m2stream.write(reinterpret_cast<char*>(&BoundingNormals[0]), sizeof(Vec3F) * BoundingNormals.size());
		}

		if (attachments.size() > 0)
		{
			m2stream.write(reinterpret_cast<char*>(&attachments[0]), sizeof(M2Attachment) * attachments.size());
			m2stream.write(reinterpret_cast<char*>(&attachTAblocks[0]), sizeof(m2SubABlock) * attachTAblocks.size());
			m2stream.write(reinterpret_cast<char*>(&attachtimestamps[0]), sizeof(uint32) * attachtimestamps.size());
			m2stream.write(reinterpret_cast<char*>(&attachVAblocks[0]), sizeof(m2SubABlock) * attachVAblocks.size());
			m2stream.write(reinterpret_cast<char*>(&attachvalues[0]), sizeof(int) * attachvalues.size());
		}

		m2stream.write(reinterpret_cast<char*>(&AttachmentLookup[0]), sizeof(int16) * AttachmentLookup.size());

		m2stream.close();
	}

	void BuildSkin(string filename)
	{
		ofstream skinstream;
		filename.append("00.skin");
		skinstream.open(filename, ios::binary);

		skinheader header;

		uint32 offset = sizeof(skinheader);

		header.id[0] = 'S';
		header.id[1] = 'K';
		header.id[2] = 'I';
		header.id[3] = 'N';
		header.nIndices = vertices.size();
		header.ofsIndices = offset;
		offset += vertices.size() * sizeof(int16);
		header.nTriangles = triangles.size() * 3;
		header.ofsTriangles = offset;
		offset += triangles.size() * sizeof(triangle);
		header.nProperties = vertices.size();
		header.ofsProperties = offset;

		vector<IndicesBone> properties;

		for (int i = 0; i < vertices.size(); ++i)
		{
			IndicesBone property;
			property.BoneIndex0 = vertices[i].BoneIndices.BoneIndex0;
			property.BoneIndex1 = vertices[i].BoneIndices.BoneIndex1;
			property.BoneIndex2 = vertices[i].BoneIndices.BoneIndex2;
			property.BoneIndex3 = vertices[i].BoneIndices.BoneIndex3;

			properties.push_back(property);
		}

		offset += properties.size() * sizeof(IndicesBone);

		header.nSubmeshes = submeshes.size();
		header.ofsSubmeshes = offset;
		offset += submeshes.size() * sizeof(submesh);
		header.nTextureUnits = TextureUnits.size();
		header.ofsTextureUnits = offset;
		offset += TexLookupTable.size() * sizeof(TextureUnit);
		header.LOD = 53;

		skinstream.write(reinterpret_cast<char*>(&header), sizeof(skinheader));

		skinstream.write(reinterpret_cast<char*>(&skinIndices[0]), sizeof(int16) * skinIndices.size());
		skinstream.write(reinterpret_cast<char*>(&triangles[0]), sizeof(triangle) * triangles.size());

		skinstream.write(reinterpret_cast<char*>(&properties[0]), sizeof(IndicesBone) * properties.size());	

		skinstream.write(reinterpret_cast<char*>(&submeshes[0]), sizeof(submesh) * submeshes.size());

		skinstream.write(reinterpret_cast<char*>(&TextureUnits[0]), sizeof(TextureUnit) * TextureUnits.size());

		skinstream.close();
	}
};
